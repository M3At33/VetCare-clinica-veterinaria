from vetcare.propietario import Propietario
from vetcare.veterinario import Veterinario
from vetcare.mascota import Mascota
from vetcare.cita import Cita
from vetcare.clinica import ClinicaVeterinaria
from vetcare.consulta_general import ConsultaGeneral
from vetcare.vacunacion import Vacunacion
from vetcare.desparasitacion import Desparasitacion
from vetcare.excepciones import (
    DatosInvalidosError,
    MascotaNoEncontradaError,
    CitaDuplicadaError
)


def ejecutar_demo():
    print("=" * 65)
    print("                 SISTEMA VETERINARIO VETCARE")
    print("=" * 65)

    clinica = ClinicaVeterinaria("VetCare - Clínica Veterinaria")

    # Personas: dos propietarios y dos profesionales.
    propietario1 = Propietario("Laura Gómez", "1001", "3001112233", "Calle 10")
    propietario2 = Propietario("Andrés Ruiz", "1002", "3002223344", "Carrera 20")

    veterinario1 = Veterinario(
        "Diana Pérez", "2001", "3101112233", "Medicina general", "TP-4587"
    )
    veterinario2 = Veterinario(
        "Carlos Rojas", "2002", "3102223344", "Medicina preventiva", "TP-6321"
    )

    print("\n--- Personal de la clínica ---")
    for persona in (propietario1, propietario2, veterinario1, veterinario2):
        print(persona.mostrar_rol())

    # Cuatro mascotas: junto con las personas y los servicios se supera el mínimo de 8 objetos.
    mascota1 = Mascota("M001", "Max", "Perro", "Labrador", 4, propietario1)
    mascota2 = Mascota("M002", "Luna", "Gato", "Criollo", 2, propietario1)
    mascota3 = Mascota("M003", "Rocky", "Perro", "Beagle", 5, propietario2)
    mascota4 = Mascota("M004", "Milo", "Gato", "Persa", 1, propietario2)

    for mascota in (mascota1, mascota2, mascota3, mascota4):
        clinica.registrar_mascota(mascota)

    # Registros clínicos de ejemplo.
    mascota1.historia_clinica.agregar_registro("Primera valoración general. Estado estable.")
    mascota2.historia_clinica.agregar_registro("Control preventivo y revisión de vacunación.")

    # Colección heterogénea: tres objetos de clases hijas diferentes.
    servicios = [
        ConsultaGeneral("S001", "Consulta general", 40000, 30),
        Vacunacion("S002", "Vacunación", 30000, "Vacuna múltiple", 1),
        Desparasitacion("S003", "Desparasitación", 20000, "Antiparasitario", 8)
    ]

    print("\n--- Demostración de polimorfismo ---")
    for servicio in servicios:
        print(f"Servicio: {servicio.descripcion}")
        print(f"Costo: ${servicio.calcular_costo():,.0f} COP")
        print(f"Indicaciones: {servicio.generar_indicaciones()}")
        print("-" * 45)

    # Citas normales.
    cita1 = Cita("C001", mascota1, veterinario1, servicios[0], "2026-11-10", "09:00")
    cita2 = Cita("C002", mascota2, veterinario2, servicios[1], "2026-11-10", "10:00")
    cita3 = Cita("C003", mascota3, veterinario1, servicios[2], "2026-11-10", "11:00")
    cita4 = Cita("C004", mascota4, veterinario2, servicios[0], "2026-11-11", "09:00")

    for cita in (cita1, cita2, cita3, cita4):
        clinica.agendar_cita(cita)

    print("\n--- Mascotas registradas ---")
    for elemento in clinica.listar_mascotas():
        print(elemento)

    print("\n--- Citas programadas ---")
    for elemento in clinica.listar_citas():
        print(elemento)

    print("\n--- Historia clínica de Max ---")
    for registro in mascota1.historia_clinica.mostrar_historial():
        print(registro)

    print("\n--- Pruebas de excepciones personalizadas ---")

    # 1. Datos inválidos.
    try:
        Mascota("M005", "", "Perro", "Criollo", 2, propietario1)
    except DatosInvalidosError as error:
        print(f"[DatosInvalidosError] {error}")

    # 2. Mascota inexistente.
    try:
        clinica.buscar_mascota("M999")
    except MascotaNoEncontradaError as error:
        print(f"[MascotaNoEncontradaError] {error}")

    # 3. Cita duplicada para la misma mascota, fecha y hora.
    try:
        cita_duplicada = Cita(
            "C005", mascota1, veterinario2, servicios[1], "2026-11-10", "09:00"
        )
        clinica.agendar_cita(cita_duplicada)
    except CitaDuplicadaError as error:
        print(f"[CitaDuplicadaError] {error}")

    print("\nEl sistema continúa funcionando después de controlar los errores.")
    print("Fin de la demostración.")


if __name__ == "__main__":
    ejecutar_demo()
