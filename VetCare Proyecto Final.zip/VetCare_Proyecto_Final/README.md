# VetCare - Sistema de Gestión de una Clínica Veterinaria

Proyecto académico desarrollado en Python para demostrar conceptos de Programación Orientada a Objetos.

## Problema que resuelve
VetCare permite organizar propietarios, mascotas, veterinarios, servicios, citas e historias clínicas mediante un programa de consola.

## Requisitos
- Python 3.10 o superior.
- No requiere librerías externas.

## Ejecución
Desde la carpeta raíz del proyecto, ejecutar:

```bash
python main.py
```

## Estructura
```text
VetCare_Proyecto_Final/
├── main.py
├── README.md
├── UML.md
├── Documento_Decisiones_de_Diseno.docx
└── vetcare/
    ├── __init__.py
    ├── excepciones.py
    ├── persona.py
    ├── propietario.py
    ├── veterinario.py
    ├── mascota.py
    ├── historia_clinica.py
    ├── cita.py
    ├── servicio.py
    ├── consulta_general.py
    ├── vacunacion.py
    ├── desparasitacion.py
    └── clinica.py
```

## Conceptos de POO
- Encapsulamiento: atributos privados y propiedades.
- Abstracción: clases abstractas `Persona` y `ServicioVeterinario`.
- Herencia: `Propietario` y `Veterinario` heredan de `Persona`; los servicios concretos heredan de `ServicioVeterinario`.
- Sobreescritura: los servicios implementan `calcular_costo()` y `generar_indicaciones()`.
- Polimorfismo: la lista `servicios` contiene instancias de tres clases distintas y se recorre invocando los mismos métodos.
- Composición: cada `Mascota` crea y contiene su propia `HistoriaClinica`.
- Excepciones: `DatosInvalidosError`, `MascotaNoEncontradaError` y `CitaDuplicadaError`.

## Pruebas incluidas
El programa principal crea más de ocho objetos, ejecuta casos normales y provoca/captura las tres excepciones personalizadas. Al final verifica que el programa continúa ejecutándose.

## Autor
Camilo Arias Arias

## Nota
Los datos, fechas, tarifas y registros incluidos son ficticios y se utilizan únicamente para demostrar el funcionamiento académico del sistema.
