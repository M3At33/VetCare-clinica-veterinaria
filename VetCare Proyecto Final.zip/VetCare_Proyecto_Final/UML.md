# Diagrama UML de clases - VetCare

```mermaid
classDiagram
    class Persona {
        <<abstract>>
        -nombre: str
        -documento: str
        -telefono: str
        +mostrar_rol()* str
    }
    class Propietario {
        -direccion: str
        -mascotas: list
        +agregar_mascota(mascota)
        +mostrar_rol() str
    }
    class Veterinario {
        -especialidad: str
        -registro_profesional: str
        -citas: list
        +asignar_cita(cita)
        +mostrar_rol() str
    }
    class Mascota {
        -codigo: str
        -nombre: str
        -especie: str
        -raza: str
        -edad: int
        -propietario: Propietario
        -historia_clinica: HistoriaClinica
        +actualizar_edad(nueva_edad)
    }
    class HistoriaClinica {
        -registros: list
        +agregar_registro(descripcion)
        +mostrar_historial()
    }
    class Cita {
        -codigo: str
        -mascota: Mascota
        -veterinario: Veterinario
        -servicio: ServicioVeterinario
        -fecha: str
        -hora: str
        -estado: str
        +cancelar()
        +resumen()
    }
    class ServicioVeterinario {
        <<abstract>>
        #codigo: str
        #descripcion: str
        #tarifa_base: float
        +calcular_costo()* float
        +generar_indicaciones()* str
    }
    class ConsultaGeneral {
        -minutos: int
        +calcular_costo() float
        +generar_indicaciones() str
    }
    class Vacunacion {
        -nombre_vacuna: str
        -dosis: int
        +calcular_costo() float
        +generar_indicaciones() str
    }
    class Desparasitacion {
        -producto: str
        -peso_referencia: float
        +calcular_costo() float
        +generar_indicaciones() str
    }
    class ClinicaVeterinaria {
        -nombre: str
        -mascotas: dict
        -citas: list
        +registrar_mascota(mascota)
        +buscar_mascota(codigo)
        +agendar_cita(cita)
    }

    Persona <|-- Propietario
    Persona <|-- Veterinario
    ServicioVeterinario <|-- ConsultaGeneral
    ServicioVeterinario <|-- Vacunacion
    ServicioVeterinario <|-- Desparasitacion
    Propietario "1" --> "0..*" Mascota : responsable
    Mascota "1" *-- "1" HistoriaClinica : composición
    Veterinario "1" --> "0..*" Cita : atiende
    Mascota "1" --> "0..*" Cita : tiene
    Cita "0..*" --> "1" ServicioVeterinario : incluye
    ClinicaVeterinaria "1" o-- "0..*" Mascota : registra
    ClinicaVeterinaria "1" o-- "0..*" Cita : programa
```

El diagrama representa la estructura propuesta en el código. La composición se establece entre `Mascota` e `HistoriaClinica`, porque la historia se crea dentro del constructor de la mascota y forma parte de su estructura.
