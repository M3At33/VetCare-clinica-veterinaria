from .excepciones import MascotaNoEncontradaError, CitaDuplicadaError


class ClinicaVeterinaria:
    """Coordina el registro de pacientes y la programación de citas."""

    def __init__(self, nombre):
        self.__nombre = nombre
        self.__mascotas = {}
        self.__citas = []

    @property
    def nombre(self):
        return self.__nombre

    @property
    def mascotas(self):
        return tuple(self.__mascotas.values())

    @property
    def citas(self):
        return tuple(self.__citas)

    def registrar_mascota(self, mascota):
        self.__mascotas[mascota.codigo] = mascota

    def buscar_mascota(self, codigo):
        try:
            return self.__mascotas[codigo]
        except KeyError:
            raise MascotaNoEncontradaError(
                f"No existe una mascota registrada con el código {codigo}."
            )

    def agendar_cita(self, cita):
        for existente in self.__citas:
            misma_mascota = existente.mascota.codigo == cita.mascota.codigo
            mismo_momento = existente.fecha == cita.fecha and existente.hora == cita.hora
            activa = existente.estado == "Programada"
            if misma_mascota and mismo_momento and activa:
                raise CitaDuplicadaError(
                    f"{cita.mascota.nombre} ya tiene una cita el {cita.fecha} a las {cita.hora}."
                )
        self.__citas.append(cita)
        cita.veterinario.asignar_cita(cita)

    def listar_mascotas(self):
        return [str(mascota) for mascota in self.__mascotas.values()]

    def listar_citas(self):
        return [cita.resumen() for cita in self.__citas]
