from .servicio import ServicioVeterinario


class Desparasitacion(ServicioVeterinario):
    def __init__(self, codigo, descripcion, tarifa_base, producto, peso_referencia):
        super().__init__(codigo, descripcion, tarifa_base)
        self.__producto = producto
        self.__peso_referencia = peso_referencia

    def calcular_costo(self):
        return self._tarifa_base + (self.__peso_referencia * 2000)

    def generar_indicaciones(self):
        return (f"Aplicar {self.__producto} únicamente según la dosis y frecuencia "
                "determinadas por el profesional veterinario.")
