from .excepciones import DatosInvalidosError


class Cita:
    """Relaciona una mascota, un veterinario y un servicio en una fecha y hora."""

    def __init__(self, codigo, mascota, veterinario, servicio, fecha, hora):
        if not all(str(v).strip() for v in (codigo, fecha, hora)):
            raise DatosInvalidosError("Código, fecha y hora de la cita son obligatorios.")
        self.__codigo = codigo
        self.__mascota = mascota
        self.__veterinario = veterinario
        self.__servicio = servicio
        self.__fecha = fecha
        self.__hora = hora
        self.__estado = "Programada"

    @property
    def codigo(self):
        return self.__codigo

    @property
    def mascota(self):
        return self.__mascota

    @property
    def veterinario(self):
        return self.__veterinario

    @property
    def servicio(self):
        return self.__servicio

    @property
    def fecha(self):
        return self.__fecha

    @property
    def hora(self):
        return self.__hora

    @property
    def estado(self):
        return self.__estado

    def cancelar(self):
        self.__estado = "Cancelada"

    def resumen(self):
        return (f"Cita {self.codigo}: {self.mascota.nombre} | "
                f"{self.servicio.descripcion} | {self.fecha} {self.hora} | "
                f"Dr(a). {self.veterinario.nombre} | {self.estado}")
