from .persona import Persona


class Propietario(Persona):
    """Persona responsable de una o varias mascotas."""

    def __init__(self, nombre, documento, telefono, direccion):
        super().__init__(nombre, documento, telefono)
        self.__direccion = direccion
        self.__mascotas = []

    @property
    def direccion(self):
        return self.__direccion

    @property
    def mascotas(self):
        return tuple(self.__mascotas)

    def agregar_mascota(self, mascota):
        if mascota not in self.__mascotas:
            self.__mascotas.append(mascota)

    def mostrar_rol(self):
        return f"Propietario: {self.nombre} | Documento: {self.documento}"
