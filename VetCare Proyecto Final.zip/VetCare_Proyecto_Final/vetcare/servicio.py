from abc import ABC, abstractmethod
from .excepciones import DatosInvalidosError


class ServicioVeterinario(ABC):
    """Clase abstracta que define la interfaz común de los servicios."""

    def __init__(self, codigo, descripcion, tarifa_base):
        if not codigo.strip() or not descripcion.strip():
            raise DatosInvalidosError("El código y la descripción del servicio son obligatorios.")
        if tarifa_base < 0:
            raise DatosInvalidosError("La tarifa base no puede ser negativa.")
        self._codigo = codigo.strip()
        self._descripcion = descripcion.strip()
        self._tarifa_base = float(tarifa_base)

    @property
    def codigo(self):
        return self._codigo

    @property
    def descripcion(self):
        return self._descripcion

    @abstractmethod
    def calcular_costo(self) -> float:
        pass

    @abstractmethod
    def generar_indicaciones(self) -> str:
        pass
