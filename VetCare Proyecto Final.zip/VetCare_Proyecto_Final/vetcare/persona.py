from abc import ABC, abstractmethod


class Persona(ABC):
    """Clase abstracta que reúne los datos comunes de las personas."""

    def __init__(self, nombre: str, documento: str, telefono: str):
        if not nombre.strip() or not documento.strip() or not telefono.strip():
            from .excepciones import DatosInvalidosError
            raise DatosInvalidosError("Nombre, documento y teléfono son obligatorios.")
        self.__nombre = nombre.strip()
        self.__documento = documento.strip()
        self.__telefono = telefono.strip()

    @property
    def nombre(self):
        return self.__nombre

    @property
    def documento(self):
        return self.__documento

    @property
    def telefono(self):
        return self.__telefono

    @abstractmethod
    def mostrar_rol(self) -> str:
        """Cada tipo de persona debe describir su función en la clínica."""
        raise NotImplementedError
