from .servicio import ServicioVeterinario


class ConsultaGeneral(ServicioVeterinario):
    def __init__(self, codigo, descripcion, tarifa_base, minutos):
        super().__init__(codigo, descripcion, tarifa_base)
        self.__minutos = minutos

    def calcular_costo(self):
        return self._tarifa_base + (self.__minutos * 500)

    def generar_indicaciones(self):
        return "Llevar a la mascota a control si los síntomas continúan y seguir la fórmula médica."
