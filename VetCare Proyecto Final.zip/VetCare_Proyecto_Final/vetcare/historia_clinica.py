from datetime import datetime


class HistoriaClinica:
    """Registro de las atenciones y observaciones de una mascota."""

    def __init__(self):
        self.__registros = []

    @property
    def registros(self):
        return tuple(self.__registros)

    def agregar_registro(self, descripcion):
        if not descripcion.strip():
            from .excepciones import DatosInvalidosError
            raise DatosInvalidosError("El registro clínico no puede estar vacío.")
        self.__registros.append({
            "fecha_registro": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "descripcion": descripcion.strip()
        })

    def mostrar_historial(self):
        if not self.__registros:
            return ["No hay registros clínicos."]
        return [
            f"{r['fecha_registro']} - {r['descripcion']}"
            for r in self.__registros
        ]
