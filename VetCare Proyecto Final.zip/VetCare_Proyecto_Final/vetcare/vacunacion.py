from .servicio import ServicioVeterinario


class Vacunacion(ServicioVeterinario):
    def __init__(self, codigo, descripcion, tarifa_base, nombre_vacuna, dosis):
        super().__init__(codigo, descripcion, tarifa_base)
        self.__nombre_vacuna = nombre_vacuna
        self.__dosis = dosis

    def calcular_costo(self):
        return self._tarifa_base + (self.__dosis * 15000)

    def generar_indicaciones(self):
        return (f"Registrar la vacuna {self.__nombre_vacuna}; observar la evolución "
                "de la mascota y respetar el calendario indicado por el veterinario.")
