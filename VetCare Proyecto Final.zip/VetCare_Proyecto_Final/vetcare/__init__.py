"""Paquete del sistema VetCare."""
