class DatosInvalidosError(Exception):
    """Se lanza cuando un dato obligatorio o un valor no es válido."""


class MascotaNoEncontradaError(Exception):
    """Se lanza cuando se consulta una mascota que no está registrada."""


class CitaDuplicadaError(Exception):
    """Se lanza cuando una mascota ya tiene una cita en la misma fecha y hora."""
