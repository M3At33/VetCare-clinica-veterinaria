from .persona import Persona


class Veterinario(Persona):
    """Profesional encargado de atender las citas."""

    def __init__(self, nombre, documento, telefono, especialidad, registro_profesional):
        super().__init__(nombre, documento, telefono)
        self.__especialidad = especialidad
        self.__registro_profesional = registro_profesional
        self.__citas = []

    @property
    def especialidad(self):
        return self.__especialidad

    @property
    def registro_profesional(self):
        return self.__registro_profesional

    @property
    def citas(self):
        return tuple(self.__citas)

    def asignar_cita(self, cita):
        self.__citas.append(cita)

    def mostrar_rol(self):
        return f"Veterinario: {self.nombre} | Especialidad: {self.especialidad}"
