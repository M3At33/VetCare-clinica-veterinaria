from .historia_clinica import HistoriaClinica
from .excepciones import DatosInvalidosError


class Mascota:
    """Paciente de la clínica. Su historia clínica forma parte de su estructura."""

    def __init__(self, codigo, nombre, especie, raza, edad, propietario):
        if not all(str(v).strip() for v in (codigo, nombre, especie, raza)):
            raise DatosInvalidosError("Código, nombre, especie y raza son obligatorios.")
        if not isinstance(edad, int) or edad < 0:
            raise DatosInvalidosError("La edad debe ser un número entero no negativo.")
        self.__codigo = str(codigo).strip()
        self.__nombre = nombre.strip()
        self.__especie = especie.strip()
        self.__raza = raza.strip()
        self.__edad = edad
        self.__propietario = propietario
        # Composición: la historia clínica se crea y pertenece a esta mascota.
        self.__historia_clinica = HistoriaClinica()
        propietario.agregar_mascota(self)

    @property
    def codigo(self):
        return self.__codigo

    @property
    def nombre(self):
        return self.__nombre

    @property
    def especie(self):
        return self.__especie

    @property
    def raza(self):
        return self.__raza

    @property
    def edad(self):
        return self.__edad

    @property
    def propietario(self):
        return self.__propietario

    @property
    def historia_clinica(self):
        return self.__historia_clinica

    def actualizar_edad(self, nueva_edad):
        if not isinstance(nueva_edad, int) or nueva_edad < 0:
            raise DatosInvalidosError("La edad debe ser un entero no negativo.")
        self.__edad = nueva_edad

    def __str__(self):
        unidad = "año" if self.edad == 1 else "años"
        return (f"{self.codigo} - {self.nombre} ({self.especie}, {self.raza}), "
                f"{self.edad} {unidad}. Responsable: {self.propietario.nombre}")
